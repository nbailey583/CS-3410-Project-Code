package seniority;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Stack;

public class SeniorityStack
{
	Stack<Employee> emp = new Stack<Employee>();
	Stack<Employee> tempStAll = new Stack<Employee>();
	Stack<Employee> empTech = new Stack<Employee>();
	Stack<Employee> tempStTech = new Stack<Employee>();
	Stack<Employee> empFin = new Stack<Employee>();
	Stack<Employee> tempStFin = new Stack<Employee>();
	Stack<Employee> empMark = new Stack<Employee>();
	Stack<Employee> tempStMark = new Stack<Employee>();
	Stack<Employee> empSupp = new Stack<Employee>();
	Stack<Employee> tempStSupp = new Stack<Employee>();
	
	public SeniorityStack(String filename) throws FileNotFoundException
	{
		//Read and parse from file
		File file = new File(filename);
		Scanner input = new Scanner(file);
		while(input.hasNextLine())
		{
			String str = input.nextLine();
			String[] tokens = str.split(", ");
			//Assuming "FirstName LastName, DateHired(MM/DD/YYYY), Department (ie. Technical, FInancial, Marketing, Support" format
			String name = tokens[0];
			String dateHired = tokens[1];
			String department = tokens[2];
			addEmp(new Employee(name,dateHired, department));
			addDeptEmp(new Employee(name, dateHired, department));
			
		}
		input.close();
	}
	
	private void addEmp(Employee e)//All Employees
	{
		while(!emp.contains(e))
		{
			Employee tempEmp = emp.peek();
			if(tempEmp.compareTo(e) == 1)
			{
				tempStAll.push(emp.pop());
			}
			else break;
		}
		emp.push(e);
		emp.addAll(tempStAll);
		
	}
	
	private void addDeptEmp(Employee e)//By Department, hopefully
	{
		
		switch (e.getDepartment())
		{
			case "TECHNICAL":
			{
				while(!empTech.contains(e))
				{
					Employee tempEmp = empTech.peek();
					if(tempEmp.compareTo(e) == 1)
					{
						tempStTech.push(empTech.pop());
					}
					else break;
				}
				empTech.push(e);
				emp.addAll(tempStTech);
				break;
			}
			
			case "FINANCIAL":
			{
				while(!empFin.contains(e))
				{
					Employee tempEmp = empFin.peek();
					if(tempEmp.compareTo(e) == 1)
					{
						tempStFin.push(empFin.pop());
					}
					else break;
				}
				empFin.push(e);
				empFin.addAll(tempStFin);
				break;
			}
			
			case "MARKETING":
			{
				while(!empMark.contains(e))
				{
					Employee tempEmp = empMark.peek();
					if(tempEmp.compareTo(e) == 1)
					{
						tempStMark.push(empMark.pop());
					}
					else break;
				}
				empMark.push(e);
				empMark.addAll(tempStMark);
				break;
			}
			
			case "SUPPORT":
			{
				while(!empSupp.contains(e))
				{
					Employee tempEmp = empSupp.peek();
					if(tempEmp.compareTo(e) == 1)
					{
						tempStSupp.push(empSupp.pop());
					}
					else break;
				}
				empSupp.push(e);
				empSupp.addAll(tempStSupp);
				break;
			}
				default:
					break;
		}
	}
	
	public  Stack<Employee> layoffAll(String date)//(MM/DD/YYYY)
	{
		Employee layoff = new Employee("Null Null", date, "Null");
		Stack<Employee> fired = new Stack<Employee>();
		for(Employee e : emp) 
		{
			if(layoff.compareTo(e) == 1)
			{
				fired.push(emp.pop());
			}
		}
		return fired;
	}
	
	public void layoffDept(String date, String dept)//(MM/DD/YYYY, Financial/Support/Technical/Marketing)
	{
		Employee layoff = new Employee("Null Null", date, dept);
		Stack<Employee> fired = new Stack<Employee>();
		switch (layoff.getDepartment())
		{
			case "TECHNICAL":
			{
				for(Employee e : empTech)
				{
					if(layoff.compareTo(e) == 1)
					{
						fired.push(empTech.pop());
					}
				}
				break;
			}
			
			case "FINANCIAL":
			{
				for(Employee e : empFin)
				{
					if(layoff.compareTo(e) == 1)
					{
						fired.push(empFin.pop());
					}
				}
				break;
			}
			
			case "MARKETING":
			{
				for(Employee e : empMark)
				{
					if(layoff.compareTo(e) == 1)
					{
						fired.push(empMark.pop());
					}
				}
				break;
			}
			
			case "SUPPORT":
			{
				for(Employee e : empSupp)
				{
					if(layoff.compareTo(e) == 1)
					{
						fired.push(empSupp.pop());
					}
				}
				break;
			}
		}
	}
}